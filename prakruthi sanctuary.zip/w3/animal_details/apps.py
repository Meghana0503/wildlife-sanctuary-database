from django.apps import AppConfig


class AnimalDetailsConfig(AppConfig):
    name = 'animal_details'
