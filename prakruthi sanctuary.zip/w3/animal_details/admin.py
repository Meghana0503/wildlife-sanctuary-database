from django.contrib import admin
from .models import Animal,Medicine,Accounts,Organisation_grants,Staff,Tourists
admin.site.register(Animal)
admin.site.register(Medicine)
admin.site.register(Accounts)
admin.site.register(Organisation_grants)
admin.site.register(Staff)
admin.site.register(Tourists)
